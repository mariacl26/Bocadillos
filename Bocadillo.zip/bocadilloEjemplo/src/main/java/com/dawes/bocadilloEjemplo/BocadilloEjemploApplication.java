package com.dawes.bocadilloEjemplo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BocadilloEjemploApplication {

	public static void main(String[] args) {
		SpringApplication.run(BocadilloEjemploApplication.class, args);
	}

}
