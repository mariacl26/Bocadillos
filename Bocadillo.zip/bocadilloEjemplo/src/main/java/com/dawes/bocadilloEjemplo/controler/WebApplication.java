package com.dawes.bocadilloEjemplo.controler;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class WebApplication {

	@GetMapping("/")
	public String home() {
		return "index";
	}

	
}
