package com.dawes.bocadilloEjemplo.interfaces;

import java.util.List;
import java.util.Optional;
import java.util.function.Function;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Example;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.repository.query.FluentQuery.FetchableFluentQuery;
import org.springframework.stereotype.Service;

import com.dawes.bocadilloEjemplo.interfacesImpl.AlumnoServiceImpl;
import com.dawes.bocadilloEjemplo.modelo.Alumno;
import com.dawes.bocadilloEjemplo.persistencia.AlumnoPersistencia;
@Service
public class AlumnoService implements AlumnoServiceImpl {

	@Autowired
	private AlumnoPersistencia ap;

	@Override
	public <S extends Alumno> S save(S entity) {
		return ap.save(entity);
	}

	@Override
	public <S extends Alumno> List<S> saveAll(Iterable<S> entities) {
		return ap.saveAll(entities);
	}

	@Override
	public <S extends Alumno> Optional<S> findOne(Example<S> example) {
		return ap.findOne(example);
	}

	@Override
	public List<Alumno> findAll(Sort sort) {
		return ap.findAll(sort);
	}

	@Override
	public void flush() {
		ap.flush();
	}

	@Override
	public Page<Alumno> findAll(Pageable pageable) {
		return ap.findAll(pageable);
	}
	

	@Override
	public Optional<Alumno> findByNombre(String nombre) {
		return ap.findByNombre(nombre);
	}

	@Override
	public <S extends Alumno> S saveAndFlush(S entity) {
		return ap.saveAndFlush(entity);
	}

	@Override
	public <S extends Alumno> List<S> saveAllAndFlush(Iterable<S> entities) {
		return ap.saveAllAndFlush(entities);
	}

	@Override
	public List<Alumno> findAll() {
		return ap.findAll();
	}

	@Override
	public List<Alumno> findAllById(Iterable<Integer> ids) {
		return ap.findAllById(ids);
	}

	@Override
	public void deleteInBatch(Iterable<Alumno> entities) {
		ap.deleteInBatch(entities);
	}

	@Override
	public <S extends Alumno> Page<S> findAll(Example<S> example, Pageable pageable) {
		return ap.findAll(example, pageable);
	}

	@Override
	public Optional<Alumno> findById(Integer id) {
		return ap.findById(id);
	}

	@Override
	public void deleteAllInBatch(Iterable<Alumno> entities) {
		ap.deleteAllInBatch(entities);
	}

	@Override
	public boolean existsById(Integer id) {
		return ap.existsById(id);
	}

	@Override
	public <S extends Alumno> long count(Example<S> example) {
		return ap.count(example);
	}

	@Override
	public void deleteAllByIdInBatch(Iterable<Integer> ids) {
		ap.deleteAllByIdInBatch(ids);
	}

	@Override
	public <S extends Alumno> boolean exists(Example<S> example) {
		return ap.exists(example);
	}

	@Override
	public void deleteAllInBatch() {
		ap.deleteAllInBatch();
	}

	@Override
	public Alumno getOne(Integer id) {
		return ap.getOne(id);
	}

	@Override
	public <S extends Alumno, R> R findBy(Example<S> example, Function<FetchableFluentQuery<S>, R> queryFunction) {
		return ap.findBy(example, queryFunction);
	}

	@Override
	public long count() {
		return ap.count();
	}

	@Override
	public void deleteById(Integer id) {
		ap.deleteById(id);
	}

	@Override
	public Alumno getById(Integer id) {
		return ap.getById(id);
	}

	@Override
	public void delete(Alumno entity) {
		ap.delete(entity);
	}

	@Override
	public void deleteAllById(Iterable<? extends Integer> ids) {
		ap.deleteAllById(ids);
	}

	@Override
	public Alumno getReferenceById(Integer id) {
		return ap.getReferenceById(id);
	}

	@Override
	public void deleteAll(Iterable<? extends Alumno> entities) {
		ap.deleteAll(entities);
	}

	@Override
	public <S extends Alumno> List<S> findAll(Example<S> example) {
		return ap.findAll(example);
	}

	@Override
	public <S extends Alumno> List<S> findAll(Example<S> example, Sort sort) {
		return ap.findAll(example, sort);
	}

	@Override
	public void deleteAll() {
		ap.deleteAll();
	}

}
