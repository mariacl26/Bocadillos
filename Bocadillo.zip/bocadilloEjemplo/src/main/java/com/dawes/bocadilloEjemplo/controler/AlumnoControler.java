package com.dawes.bocadilloEjemplo.controler;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;

import com.dawes.bocadilloEjemplo.interfaces.AlumnoService;
import com.dawes.bocadilloEjemplo.modelo.Alumno;

@Controller
@RequestMapping("/alumnos")
public class AlumnoControler {
	@Autowired
	AlumnoService as;

	@PostMapping("/insertar")
	public ResponseEntity<?> insert(@RequestBody Alumno user) {
		Alumno savedUser;
		Map<String, Object> response = new HashMap<String, Object>();
		try {
			savedUser = as.save(user);
		} catch (Exception e) {
			return new ResponseEntity<Map<String, Object>>(response, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return new ResponseEntity<Alumno>(savedUser, HttpStatus.OK);
	}

	@GetMapping("/buscar")
	public ResponseEntity<?> findAll() {
		Map<String, Object> response = new HashMap<String, Object>();
		try {
			List<Alumno> alumnos = as.findAll();
			return new ResponseEntity<List<Alumno>>(alumnos, HttpStatus.OK);
		} catch (Exception e) {
			response.put("message", "error al buscar los usuarios");
			return new ResponseEntity<Map<String, Object>>(response, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@GetMapping("/findByNombre/{nombre}")
	public ResponseEntity<?> findByNombre(@PathVariable String nombre) {
		Map<String, Object> response = new HashMap<String, Object>();
		try {
			Optional<Alumno> alumno = as.findByNombre(nombre);
			if (alumno.isPresent()) {
				return new ResponseEntity<Alumno>(alumno.get(), HttpStatus.OK);
			} else {
				response.put("message", "No se encontró ningún alumno con el nombre proporcionado");
				return new ResponseEntity<Map<String, Object>>(response, HttpStatus.NOT_FOUND);
			}
		} catch (Exception e) {
			response.put("message", "Error al buscar el alumno por nombre");
			return new ResponseEntity<Map<String, Object>>(response, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

}
