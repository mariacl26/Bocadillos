package com.dawes.bocadilloEjemplo.persistencia;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.dawes.bocadilloEjemplo.modelo.Alumno;

public interface AlumnoPersistencia extends JpaRepository<Alumno, Integer> {

	public Optional<Alumno> findByNombre(String nombre);
}
