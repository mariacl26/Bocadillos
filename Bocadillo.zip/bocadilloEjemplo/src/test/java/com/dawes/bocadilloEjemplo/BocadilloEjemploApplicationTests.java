package com.dawes.bocadilloEjemplo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BocadilloEjemploApplicationTests {

	@Test
	void contextLoads() {
	}

}
